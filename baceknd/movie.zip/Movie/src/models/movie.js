const mongoose = require('mongoose');

const movieSchema = new mongoose.Schema({
  title: { type: String, required: true },
  image: { type: String },
  language: { type: String, required: true },
  genre: { type: String, required: true },
  director: { type: String, required: true },
  trailer: { type: String },
  description: { type: String, required: true },
  duration: { type: Number, required: true }, // duration in minutes
  startDate: { type: Date, required: true },
  endDate: { type: Date, required: true },
});
const Movie = mongoose.model('Movie', movieSchema);
module.exports = Movie;