
const Movie = require('../models/movie');

// Add a new movie
exports.addMovie = async (req, res) => {
    try {
      const movie = new Movie(req.body);
    
    
    // const movie = Movie.create(req.body);
    // console.log(movie);
      await movie.save();
      res.status(201).json(movie);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  };

  // Delete a movie
exports.deleteMovie = async (req, res) => {
    try {
      const { id } = req.params;
      await Movie.findByIdAndDelete(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  };

  // Update an existing movie
exports.updateMovie = async (req, res) => {
    try {
      const { id } = req.params;
      const movie = await Movie.findByIdAndUpdate(id, req.body, { new: true });
      res.status(200).json(movie);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  };