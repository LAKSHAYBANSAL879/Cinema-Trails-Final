const express = require('express');
const AdminController = require('../../controllers/admin-controller');
const router = express.Router();
// Admin routes
router.post('/admin/movies', AdminController.addMovie);
router.put('/admin/movies/:id', AdminController.updateMovie);
router.delete('/admin/movies/:id', AdminController.deleteMovie);
module.exports = router;
