const express = require('express');
const movieRoutes = require('./routes/index');
const connect = require('./config/database');
const bodyParser = require('body-parser');

const mongoose = require('mongoose');
const PORT = 3000;
const setupandstartserver = async() => {


const app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:true}));
app.use('/api',movieRoutes);
// app.use(express.json());
// app.use(bodyParser.json());
// app.use(bodyParser.urlencoded({extended:true}));
app.listen(PORT, async () => {
    console.log(`Server is running on port ${PORT}`);
    await connect();
    console.log('mongo-db connected');
  });
}
setupandstartserver();